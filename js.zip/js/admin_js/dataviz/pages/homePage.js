/*-- =============================================================================
     =============================================================================

       ###     ###      #########      #####       #####    ############
       ###     ###    #############    ######     ######    ############
       ###########    ###       ###    ### ###   ### ###    ###
       ###########    ###       ###    ###  ### ###  ###    ##########
       ###     ###    ###       ###    ###   #####   ###    ##########
       ###     ###    ###       ###    ###    ###    ###    ###
       ###     ###    #############    ###    ###    ###    ############   ####
       ###     ###      #########      ###    ###    ###    ############   ####

     =============================================================================
     ======================================================================== --*/

// ./JS/pages/homePage.js
import { CONFIG, state } from "../core/app.js";
import { getRowsForYear, getYears } from "../core/dataManager.js";
import { withPreservedScroll, wireCustomYearSelect, euro, fmtDateNL, startOfDay, clamp } from "../core/ui-helpers.js";

export const HomePage = {
  id: "home",
  title: "Home",
  template: () => `
    <div class="container">
      <!-- ====== KPI-CARDS ====== -->
      <div class="kpi-header">
        <div class="kpi-header__left">
          <h3 class="kpi-header__title">Overzicht</h3>
          <p class="kpi-header__subtitle">Kies een jaar</p>
        </div>

        <div class="year-select-container">
          <div class="custom-select custom-select-kpi" id="yearSelectContainerKpi">
            <div class="select-trigger">
              <span id="selectedYearDisplayKpi">—</span>
              <i class="fa-solid fa-chevron-down"></i>
            </div>
            <div class="select-options" id="yearOptionsKpi"></div>
            <input type="hidden" id="yearValueKpi" value="">
          </div>
        </div>
      </div>

      <section class="cards-grid">
        <div class="kpi-card">
          <span class="label">Boekingen</span>
          <span id="kpiBookings" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Nachten geboekt</span>
          <span id="kpiNights" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Eigen boekingen</span>
          <span id="kpiOwnerBookings" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Nachten zelf geboekt</span>
          <span id="kpiOwnerNights" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">% al geboekt (jaar)</span>
          <span id="kpiOccupancyPct" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Nachten ongeboekt</span>
          <span id="kpiNightsFree" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Omzet (Bruto)</span>
          <span id="kpiGrossRevenue" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Gem. bruto / nacht</span>
          <span id="kpiGrossRevPerNight" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Omzet (Netto)</span>
          <span id="kpiNetRevenue" class="value">—</span>
        </div>
        <div class="kpi-card">
          <span class="label">Gem. netto / nacht</span>
          <span id="kpiNetRevPerNight" class="value">—</span>
        </div>
      </section>

      <!-- ====== Booking Cards Carousel ====== -->
      <section class="content-section">
        <div class="booking-carousel" id="bookingCarousel" style="display:none;">
          <div class="booking-carousel__track" id="bookingCarouselTrack"></div>
        </div>
        <div class="booking-scrollbar" id="bookingScrollbar" aria-label="Booking pager">
          <div class="booking-scrollbar__rail">
            <div class="booking-scrollbar__ticks" id="bookingTicks"></div>
            <div class="booking-scrollbar__knob" id="bookingKnob"></div>
          </div>
        </div>
      </section>

      <!-- ====== SEIZOENSINZICHTEN ====== -->
      <section class="content-section">
        <div class="chart-panel">
          <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 class="panel-title" style="margin: 0;">Seizoensinzichten</h3>
            <div class="year-select-container">
              <div class="custom-select custom-select-seizoen" id="yearSelectContainer">
                <div class="select-trigger">
                  <span id="selectedYearDisplay">—</span>
                  <i class="fa-solid fa-chevron-down"></i>
                </div>
                <div class="select-options" id="yearOptions"></div>
                <input type="hidden" id="yearValue" value="">
              </div>
            </div>
          </div>
          <div class="season-filter">
            <button class="filter-btn active" data-season="all">Jaar</button>
            <button class="filter-btn" data-season="winter">Winter</button>
            <button class="filter-btn" data-season="spring">Lente</button>
            <button class="filter-btn" data-season="summer">Zomer</button>
            <button class="filter-btn" data-season="autumn">Herfst</button>
          </div>
          <div class="chart-container">
            <canvas id="chartHomeRevenue"></canvas>
          </div>
          <div class="mode-toggle">
            <button id="btnGross" class="toggle-btn active">Bruto</button>
            <button id="btnNet" class="toggle-btn">Netto</button>
          </div>
        </div>
      </section>

      <!-- ====== CUMULATIEVE OMZET ====== -->
      <section class="content-section">
        <div class="chart-panel">
          <div class="panel-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h3 class="panel-title" style="margin: 0;">Overzicht boekingen</h3>
            <div class="year-select-container">
              <div class="custom-select custom-select-cumulative" id="cumulativeYearSelectContainer">
                <div class="select-trigger">
                  <span id="cumulativeYearDisplay">—</span>
                  <i class="fa-solid fa-chevron-down"></i>
                </div>
                <div class="select-options" id="cumulativeYearOptions"></div>
                <input type="hidden" id="cumulativeYearValue" value="">
              </div>
            </div>
          </div>
          <div class="panel__body">
            <div class="chart-scroll" id="cumScrollWrapper">
              <div class="cum-y-axis" id="cumYAxis"></div>
              <div class="chart-scroll__inner" id="cumScrollInner">
                <canvas id="chartCumulative"></canvas>
              </div>
            </div>
            <div class="hint">
              <span class="hint-text">Scroll horizontaal voor details</span>
              <span class="hint-separator">•</span>
              <span class="hint-legend">
                <span class="dot dot-orange"></span>
                <span>Huiseigenaar</span>
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  `,
  init: async () => {
    await render();
  }
};

/**
 * Main render function for the Home Page
 */
async function render() {
  const kpiYear = state.kpiYear ?? "ALL";
  renderHomeKPIsForYear(kpiYear);

  renderHomeBookingCarousel(state.rawRows);
  renderHomeRevenueChart();

  const y = state.cumulativeYear ?? state.currentYear;
  if (y != null) renderHomeCumulativeRevenueChartForYear(y);

  // Bind home-specific buttons
  bindSeasonButtons();
  bindModeButtons();
  
  // Setup year selects for home
  setupHomeYearSelects();
}

/**
 * Setup year selects specifically for the Home page
 */
function setupHomeYearSelects() {
  const years = getYears();
  const availableYears = years.length > 0 ? years : [state.currentYear || new Date().getFullYear()];

  wireCustomYearSelect({
    containerId: "yearSelectContainerKpi",
    displayId: "selectedYearDisplayKpi",
    optionsId: "yearOptionsKpi",
    hiddenId: "yearValueKpi",
    years: ["ALL", ...availableYears],
    get: () => state.kpiYear ?? "ALL",
    set: (y) => (state.kpiYear = y),
    onChange: () => withPreservedScroll(() => renderHomeKPIsForYear(state.kpiYear ?? "ALL")),
  });

  wireCustomYearSelect({
    containerId: "yearSelectContainer",
    displayId: "selectedYearDisplay",
    optionsId: "yearOptions",
    hiddenId: "yearValue",
    years: availableYears,
    get: () => state.currentYear,
    set: (y) => (state.currentYear = y),
    onChange: () => withPreservedScroll(render),
  });

  wireCustomYearSelect({
    containerId: "cumulativeYearSelectContainer",
    displayId: "cumulativeYearDisplay",
    optionsId: "cumulativeYearOptions",
    hiddenId: "cumulativeYearValue",
    years: ["ALL", ...availableYears],
    get: () => state.cumulativeYear ?? "ALL",
    set: (y) => (state.cumulativeYear = y),
    onChange: () => withPreservedScroll(() => renderHomeCumulativeRevenueChartForYear(state.cumulativeYear ?? "ALL")),
  });
}

function bindSeasonButtons() {
  document.querySelectorAll(".filter-btn").forEach((btn) => {
    btn.onclick = () => {
      document.querySelectorAll(".filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.currentSeason = btn.dataset.season;
      withPreservedScroll(renderHomeRevenueChart);
    };
  });
}

function bindModeButtons() {
  const gross = document.getElementById("btnGross");
  const net = document.getElementById("btnNet");
  if (!gross || !net) return;

  gross.onclick = () => {
    gross.classList.add("active");
    net.classList.remove("active");
    state.currentMode = "gross";
    withPreservedScroll(render);
  };

  net.onclick = () => {
    net.classList.add("active");
    gross.classList.remove("active");
    state.currentMode = "net";
    withPreservedScroll(render);
  };
}

/* ============================================================
 * HOME KPI CARDS
 * ============================================================ */

export function renderHomeKPIsForYear(yearOrAll) {
  if (!state.rawRows || state.rawRows.length === 0) return;

  const rows =
    yearOrAll === "ALL" || yearOrAll == null
      ? state.rawRows
      : getRowsForYear(yearOrAll);

  renderHomeKPIs(rows);
}

function renderHomeKPIs(allRows) {
  if (!allRows || allRows.length === 0) return;

  const platformRows = allRows.filter((r) => !r.__owner);
  const ownerRows = allRows.filter((r) => r.__owner);

  const bookings = platformRows.length;
  const ownerBookings = ownerRows.length;

  const nights = platformRows.reduce((s, r) => s + (r.__nights || 0), 0);
  const ownerNights = ownerRows.reduce((s, r) => s + (r.__nights || 0), 0);

  const totalOccupied = nights + ownerNights;

  // ALL -> kan meerdere jaren bevatten, jaarselect -> meestal 1 jaar
  const yearsInData = Math.max(1, getUniqueYearsCount(allRows));
  const totalDays = yearsInData * CONFIG.DAYS_IN_YEAR;

  const occupancyPct = totalDays > 0 ? totalOccupied / totalDays : 0;

  const grossRevenue = platformRows.reduce((s, r) => s + (r.__gross || 0), 0);
  const netRevenue = platformRows.reduce((s, r) => s + (r.__net || 0), 0);

  // ints
  setCountUp("kpiBookings", bookings, { formatter: (v) => String(Math.round(v)) });
  setCountUp("kpiNights", nights, { formatter: (v) => String(Math.round(v)) });
  setCountUp("kpiOwnerBookings", ownerBookings, { formatter: (v) => String(Math.round(v)) });
  setCountUp("kpiOwnerNights", ownerNights, { formatter: (v) => String(Math.round(v)) });

  setCountUp("kpiNightsFree", Math.max(0, totalDays - totalOccupied), { formatter: (v) => String(Math.round(v)), });

  // percentage (1 decimaal)
  setCountUp("kpiOccupancyPct", occupancyPct * 100, { formatter: (v) => `${v.toFixed(1)}%`, });

  // euro’s
  setCountUp("kpiGrossRevenue", grossRevenue, { formatter: (v) => euro(v), });
  setCountUp("kpiGrossRevPerNight", nights > 0 ? grossRevenue / nights : 0, { formatter: (v) => euro(v), });

  setCountUp("kpiNetRevenue", netRevenue, { formatter: (v) => euro(v), });
  setCountUp("kpiNetRevPerNight", nights > 0 ? netRevenue / nights : 0, { formatter: (v) => euro(v), });
}






let carouselObserver = null;

export function renderHomeBookingCarousel(allRows) {
  // --- DOM refs ---
  const carousel = document.getElementById("bookingCarousel");
  const track = document.getElementById("bookingCarouselTrack");

  // (oude dots blijven bestaan, maar worden vervangen door knob/ticks)
  const dotsWrap = document.getElementById("bookingCarouselDots");

  const prevBtn = document.getElementById("bookingPrevBtn");
  const nextBtn = document.getElementById("bookingNextBtn");

  // nieuwe pager elementen
  const knob = document.getElementById("bookingKnob");
  const ticksWrap = document.getElementById("bookingTicks");

  if (!carousel || !track) return;

  if (!allRows || allRows.length === 0) {
    carousel.style.display = "none";
    return;
  }

  // ------------------------------------------------------------
  // Helpers
  // ------------------------------------------------------------

  const fmtRange = (a, b) => {
    if (!a || !b) return "—";
    const aStr = a.toLocaleDateString("nl-NL", { weekday: "short", day: "numeric", month: "short" });
    const bStr = b.toLocaleDateString("nl-NL", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
    return `${aStr} → ${bStr}`;
  };

  const normalizePhone = (v) => {
    if (v == null || v === "") return "";
    if (typeof v === "number" && Number.isFinite(v)) return String(Math.trunc(v));
    return String(v).replace(/[^\d+]/g, "");
  };

  // ------------------------------------------------------------
  // 1) Normalize rows (matchend met jouw Excel headers)
  // ------------------------------------------------------------
  const rows = allRows
    .map((r) => {
      const bRaw = r.__bookingRaw || "";
      const source = bRaw.includes("|")
        ? bRaw.split("|")[1].trim()
        : (r.__owner ? "Huiseigenaar" : "");

      return {
        aankomst: r.__aankomst,
        vertrek: r.__vertrek,
        nights: r.__nights,
        guest: r.__guest,
        owner: r.__owner,
        source: source,
        adults: r.__adults,
        kids: r.__kids,
        babies: r.__babies,
        phone: normalizePhone(r.__phone),
        email: r.__email,
        countryCode: r.__countryCode,
        gross: r.__gross,
        net: r.__net,
      };
    })
    .filter((x) => x.aankomst && x.vertrek)
    .sort((a, b) => a.aankomst - b.aankomst);

  if (!rows.length) {
    carousel.style.display = "none";
    return;
  }

  // ------------------------------------------------------------
  // 2) start index: NU (als aanwezig), anders eerst VOLGENDE
  // ------------------------------------------------------------
  const now = startOfDay(new Date());
  const currentIdx = rows.findIndex((r) => r.aankomst <= now && now < r.vertrek);
  const nextIdx = rows.findIndex((r) => r.aankomst > now);
  const startIndex = currentIdx !== -1 ? currentIdx : (nextIdx !== -1 ? nextIdx : 0);

  // ------------------------------------------------------------
  // 2b) Pager (dots/knob) helpers
  // ------------------------------------------------------------

  // (oude dots helper blijft bestaan; wordt nog aangeroepen maar is optioneel)
  const setActiveDot = (idx) => {
    if (dotsWrap) {
      [...dotsWrap.children].forEach((d, i) => d.classList.toggle("is-active", i === idx));
    }
    // Geef de huidige slide de actieve klasse (voor dimmen van buren op desktop)
    [...track.children].forEach((slide, i) => slide.classList.toggle("is-active", i === idx));
  };

  const updateKnob = (idx) => {
    if (!knob) return;

    const rail = knob.closest(".booking-scrollbar__rail");
    if (!rail) return;

    const railRect = rail.getBoundingClientRect();
    const padding = 14; // moet matchen met CSS ticks padding
    const usable = Math.max(0, railRect.width - padding * 2);

    const maxIdx = Math.max(1, rows.length - 1);
    const t = idx / maxIdx; // 0..1
    const x = padding + usable * t;

    knob.style.left = `${x}px`;
  };

  // ------------------------------------------------------------
  // 2c) Scroll helpers
  // ------------------------------------------------------------
  const getXForIndex = (idx) => {
    const slides = [...track.children];
    if (!slides[idx]) return 0;
    return slides[idx].offsetLeft - (carousel.clientWidth / 2) + (slides[idx].clientWidth / 2);
  };

  const scrollToIndex = (idx, smooth = true) => {
    carousel.scrollTo({
      left: getXForIndex(idx),
      behavior: smooth ? "smooth" : "instant",
    });
    
    setActiveDot(idx);
    updateKnob(idx);
  };

  const getClosestIndex = () => {
    if (!carousel || !track.children.length) return 0;
    const slides = [...track.children];
    const centerX = carousel.scrollLeft + (carousel.clientWidth / 2);
    
    let closestIdx = 0;
    let minDiff = Infinity;
    
    slides.forEach((slide, i) => {
      const slideCenter = slide.offsetLeft + (slide.clientWidth / 2);
      const diff = Math.abs(centerX - slideCenter);
      if (diff < minDiff) {
        minDiff = diff;
        closestIdx = i;
      }
    });
    
    return closestIdx;
  };

  // ------------------------------------------------------------
  // 3) render
  // ------------------------------------------------------------
  track.innerHTML = "";

  // dots: blijven bestaan, maar mogen leeg blijven als je overgaat op knob
  if (dotsWrap) dotsWrap.innerHTML = "";

  // ticks bouwen voor knob-rail
  if (ticksWrap) {
    ticksWrap.innerHTML = "";
    rows.forEach(() => {
      const t = document.createElement("div");
      t.className = "booking-tick";
      ticksWrap.appendChild(t);
    });
  }

  rows.forEach((picked, idx) => {
    const isNow = picked.aankomst <= now && now < picked.vertrek;
    const isNext = !isNow && picked.aankomst > now;

    const statusText = isNow ? "NU" : (isNext ? "VOLGENDE" : "VERLEDEN");
    const statusClass = isNow ? "badge--now" : (isNext ? "badge--next" : "badge--muted");

    // breakdown: alleen >0
    const breakdownParts = [];
    if ((picked.adults || 0) > 0) breakdownParts.push(`${picked.adults} volwassenen`);
    if ((picked.kids || 0) > 0) breakdownParts.push(`${picked.kids} kinderen`);
    if ((picked.babies || 0) > 0) breakdownParts.push(`${picked.babies} baby`);
    const breakdown = breakdownParts.length ? `(${breakdownParts.join(", ")})` : "—";

    const totalGuests = (picked.adults || 0) + (picked.kids || 0) + (picked.babies || 0);

    const sourceParts = [];
    if (picked.owner) sourceParts.push("Huiseigenaar");
    if (picked.source && !picked.owner) sourceParts.push(picked.source);
    const sourceText = sourceParts.join(" • ");

    const cc = (picked.countryCode || "").trim().toUpperCase();
    const flagUrl = cc ? `https://flagcdn.com/w40/${cc.toLowerCase()}.png` : "";

    // --- FACTUUR BEREKENING ---
    const amount = (picked.gross && picked.gross !== 0) ? picked.gross : picked.net;
    const rent = amount; // Base price (gross)
    const cleaning = picked.owner ? 0 : 350.00;
    const bedLinen = picked.owner ? 0 : (totalGuests * 20.95);
    const touristTax = totalGuests * picked.nights * 2.50;
    const mobilityFee = totalGuests * picked.nights * 0.50;
    const commission = rent * 0.24;

    const totalSettlement = rent + cleaning + bedLinen + touristTax + mobilityFee - commission;

    const fmtSettlement = (val) => {
      return val.toLocaleString("nl-NL", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    };

    const slide = document.createElement("div");
    slide.className = "booking-slide";
    slide.dataset.index = idx; // ✅ Index opslaan voor de observer
    slide.innerHTML = `
      <div class="booking-card-flip-container" onclick="this.classList.toggle('is-flipped')">
        <div class="booking-card-flipper">
          
          <!-- FRONT -->
          <div class="chart-panel booking-card booking-card--v2 booking-card--front">
            <div class="booking-card__header">
              <h3 class="booking-card__title">Boeking</h3>
              <div class="booking-card__badges">
                <span class="badge ${statusClass}">${statusText}</span>
                ${sourceText ? `<span class="badge badge--muted ${picked.owner ? "badge--owner" : ""}">${sourceText}</span>` : ""}
                <button class="flip-btn" title="Bekijk factuur"><i class="fa-solid fa-file-invoice"></i></button>
              </div>
            </div>

            <div class="booking-card__divider"></div>

            <div class="booking-card__top">
              <div class="booking-card__left">
                <div class="booking-card__guest">${picked.guest || "—"}</div>

                <div class="booking-card__row booking-card__row--strong">
                  <i class="fa-solid fa-user"></i>
                  <span><strong>${totalGuests || "—"}</strong> gasten</span>
                </div>

                <div class="booking-card__sub">${breakdown}</div>
              </div>

              <div class="booking-card__country">
                ${flagUrl ? `<img class="booking-card__flag" src="${flagUrl}" alt="Flag" />` : ""}
                <div class="booking-card__countryCode">${cc || "—"}</div>
              </div>
            </div>

            <div class="booking-card__rows">
              <div class="booking-card__row">
                <i class="fa-regular fa-calendar"></i>
                <span>${fmtRange(picked.aankomst, picked.vertrek)}</span>
              </div>

              <div class="booking-card__row">
                <i class="fa-regular fa-moon"></i>
                <span>${picked.nights || 0} nachten</span>
              </div>

              ${picked.phone ? `
                <div class="booking-card__row">
                  <i class="fa-solid fa-phone" onclick="event.stopPropagation()"></i>
                  <a class="booking-card__link" href="tel:${picked.phone.replace(/\s+/g, "")}" onclick="event.stopPropagation()">${picked.phone}</a>
                </div>` : ""}

              ${picked.email ? `
                <div class="booking-card__row">
                  <i class="fa-regular fa-envelope" onclick="event.stopPropagation()"></i>
                  <a class="booking-card__link" href="mailto:${picked.email}" onclick="event.stopPropagation()">${picked.email}</a>
                </div>` : ""}
            </div>

            <div class="booking-card__divider booking-card__divider--bottom"></div>

            <div class="booking-card__price">${fmtEUR(amount)}</div>
          </div>
          
          <!-- BACK (Settlement) -->
          <div class="chart-panel booking-card booking-card--v2 booking-card--back">
            <div class="booking-card__header">
              <h3 class="booking-card__title">Factuur specificatie</h3>
            </div>
            
            <div class="booking-card__divider"></div>
            
            <div class="settlement-table">
              <div class="settlement-row">
                <span class="settle-label">Huur</span>
                <span class="settle-val">€ ${fmtSettlement(rent)}</span>
              </div>
              <div class="settlement-row">
                <span class="settle-label">Schoonmaak</span>
                <span class="settle-val">${picked.owner ? 'n.t.b.' : '€ ' + fmtSettlement(cleaning)}</span>
              </div>
              <div class="settlement-row">
                <span class="settle-label">Bedlinnen</span>
                <span class="settle-val">${picked.owner ? 'n.v.t.' : '€ ' + fmtSettlement(bedLinen)}</span>
              </div>
              <div class="settlement-row">
                <span class="settle-label">Toeristenbelasting</span>
                <span class="settle-val">€ ${fmtSettlement(touristTax)}</span>
              </div>
              <div class="settlement-row">
                <span class="settle-label">Mobiliteitsheffing</span>
                <span class="settle-val">€ ${fmtSettlement(mobilityFee)}</span>
              </div>
              
              <div class="settlement-row settlement-row--commission">
                <span class="settle-label">Commissie factuur</span>
                <span class="settle-val">€ -${fmtSettlement(commission)}</span>
              </div>
              
              <div class="settlement-row settlement-row--total">
                <span class="settle-label">Totaal bedrag</span>
                <span class="settle-val">€ ${fmtSettlement(totalSettlement)}</span>
              </div>
            </div>

          </div>
        </div>
      </div>
    `;

    track.appendChild(slide);

    // oude dots blijven werken als je ze nog gebruikt (optioneel)
    if (dotsWrap) {
      const dot = document.createElement("div");
      dot.className = "booking-dot" + (idx === startIndex ? " is-active" : "");
      dot.addEventListener("click", () => scrollToIndex(idx));
      dotsWrap.appendChild(dot);
    }
  });

  // ------------------------------------------------------------
  // 4) show + scroll to start
  // ------------------------------------------------------------
  carousel.style.display = "block";
  requestAnimationFrame(() => {
    scrollToIndex(startIndex, false);
    updateKnob(startIndex);
    setActiveDot(startIndex); // Zorg dat de eerste kaart direct actief is
  });

  // ------------------------------------------------------------
  // 5) nav buttons (desktop)
  // ------------------------------------------------------------
  if (prevBtn) prevBtn.onclick = () => scrollToIndex(Math.max(0, getClosestIndex() - 1));
  if (nextBtn) nextBtn.onclick = () => scrollToIndex(Math.min(rows.length - 1, getClosestIndex() + 1));

  // ------------------------------------------------------------
  // 6) Intersection Observer voor precisie-highlighting
  // ------------------------------------------------------------
  if (carouselObserver) carouselObserver.disconnect();

  const observerOptions = {
    root: carousel,
    rootMargin: "0px -48% 0px -48%", // Focus gebied: een hele smalle verticale strip in het midden
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const slideIndex = parseInt(entry.target.dataset.index);
        setActiveDot(slideIndex);
        updateKnob(slideIndex);
      }
    });
  }, observerOptions);

  [...track.children].forEach(slide => observer.observe(slide));

  // ------------------------------------------------------------
  // 7) Draggable pager knob — pointer capture op de knob zelf
  // ------------------------------------------------------------
  const rail = knob ? knob.closest(".booking-scrollbar__rail") : null;

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

  const indexFromClientX = (clientX) => {
    if (!rail) return 0;
    const rect = rail.getBoundingClientRect();
    const padding = 14;
    const usable = Math.max(1, rect.width - padding * 2);
    const x = clamp(clientX - rect.left - padding, 0, usable);
    return Math.round((x / usable) * Math.max(1, rows.length - 1));
  };

  if (knob && rail) {
    let isDragging = false;

    knob.addEventListener("pointerdown", (e) => {
      isDragging = true;
      knob.setPointerCapture(e.pointerId); // ✅ alle events komen nu op knob
      e.preventDefault();
    }, { passive: false });

    // ✅ pointermove op knob (niet window) — werkt correct met pointer capture
    knob.addEventListener("pointermove", (e) => {
      if (!isDragging) return;
      e.preventDefault();

      const idx = indexFromClientX(e.clientX);
      updateKnob(idx);           // knob positie live bijwerken
      setActiveDot(idx);

      // ✅ Scroll carousel live tijdens drag
      carousel.scrollTo({ left: getXForIndex(idx), behavior: "instant" });
    }, { passive: false });

    const stopDrag = (e) => {
      if (!isDragging) return;
      isDragging = false;
      try { knob.releasePointerCapture(e.pointerId); } catch (_) { }

      // Snap naar dichtstbijzijnde slide na loslaten
      const idx = indexFromClientX(e.clientX);
      scrollToIndex(idx, true);
    };

    knob.addEventListener("pointerup", stopDrag, { passive: false });
    knob.addEventListener("pointercancel", stopDrag, { passive: false });

    // Klik/tap op rail (niet op knob) = direct naar positie springen
    rail.addEventListener("pointerdown", (e) => {
      if (e.target === knob || knob.contains(e.target)) return;
      const idx = indexFromClientX(e.clientX);
      scrollToIndex(idx, true);
    }, { passive: true });
  }

}


/* ============================================================
 * HOME: Omzet per maand (BAR)
 * ============================================================ */

export function renderHomeRevenueChart() {
  if (!state.rawRows || state.rawRows.length === 0) return;

  const yearRows = getRowsForYear(state.currentYear);

  const monthlyData = {}; // monthIndex => {gross, net}
  yearRows.forEach((row) => {
    const m = row.__aankomst.getMonth();
    if (!monthlyData[m]) monthlyData[m] = { gross: 0, net: 0 };
    monthlyData[m].gross += row.__gross || 0;
    monthlyData[m].net += row.__net || 0;
  });

  // ✅ Altijd alle maanden (0..11), ook als er geen boekingen zijn
  let monthIndices = Array.from({ length: 12 }, (_, i) => i);

  // Seizoensfilter (toont nog steeds de maanden van dat seizoen, ook als ze 0 zijn)
  if (state.currentSeason !== "all") {
    const allowed = CONFIG.SEASON_MAP[state.currentSeason] || [];
    monthIndices = monthIndices.filter((m) => allowed.includes(m));
  }

  const labels = monthIndices.map((m) =>
    new Date(state.currentYear, m, 1)
      .toLocaleString("nl-NL", { month: "short" })
      .toUpperCase()
  );

  // ✅ Default 0 voor maanden zonder data
  const values = monthIndices.map((m) => {
    const entry = monthlyData[m];
    if (!entry) return 0;
    return entry[state.currentMode] ?? 0;
  });

  const canvas = document.getElementById("chartHomeRevenue");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");

  // Gebruik een unieke key zodat later andere pagina’s ook chart keys kunnen hebben
  if (state.charts?.homeRevenueBar) state.charts.homeRevenueBar.destroy();

  // ✅ Seizoenskleuren mapping
  const SEASON_COLORS = {
    winter: "#3b82f6",
    spring: "#10b981",
    summer: "#f59e0b",
    autumn: "#ef4444"
  };

  const barColors = monthIndices.map(m => {
    if (CONFIG.SEASON_MAP.winter.includes(m)) return SEASON_COLORS.winter;
    if (CONFIG.SEASON_MAP.spring.includes(m)) return SEASON_COLORS.spring;
    if (CONFIG.SEASON_MAP.summer.includes(m)) return SEASON_COLORS.summer;
    if (CONFIG.SEASON_MAP.autumn.includes(m)) return SEASON_COLORS.autumn;
    return "#3b82f6";
  });

  state.charts.homeRevenueBar = new Chart(ctx, {
    type: "bar",
    data: {
      labels,
      datasets: [{ 
        data: values, 
        backgroundColor: barColors, // ✅ Gebruik array voor seizoenskleuren
        borderRadius: 6 
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: {
          beginAtZero: true,
          grid: { color: "rgba(255,255,255,0.05)" },
          ticks: { color: "#8b949e", font: { size: 13 } },
        },
        x: {
          grid: { display: false },
          ticks: {
            color: "#8b949e",
            font: { size: 13 },
            autoSkip: false,
            maxRotation: 45,
            minRotation: 45,
            padding: 8,
          },
        },
      },

    },
  });
}


/* ============================================================
 * HOME: Cumulatieve omzet (LINE, stepped)
 * ============================================================ */

export function renderHomeCumulativeRevenueChartForYear(yearOrAll) {
  if (!state.rawRows || state.rawRows.length === 0) return;

  const rows =
    yearOrAll === "ALL" || yearOrAll == null
      ? state.rawRows
      : getRowsForYear(yearOrAll);

  renderHomeCumulativeRevenueChart(rows);
}


function renderHomeCumulativeRevenueChart(rows) {
  const canvas = document.getElementById("chartCumulative");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  const data = aggCumulativeDaily(rows);

  if (state.charts?.homeCumulativeRevenue) state.charts.homeCumulativeRevenue.destroy();

  setScrollableChartWidth(data.labels.length);

  state.charts.homeCumulativeRevenue = new Chart(ctx, {
    type: "line",
    data: {
      labels: data.labels,
      datasets: [
        {
          label: "Cumulatieve omzet",
          data: data.values,
          borderColor: "#3b82f6",
          backgroundColor: "rgba(59,130,246,0.12)",
          fill: true,
          stepped: true,
          borderWidth: 3,
          tension: 0,

          // alleen punten op boekingsdagen
          pointRadius: (c) => (data.pointsMeta[c.dataIndex]?.isBooking ? 8 : 0),
          pointHoverRadius: 10,
          pointBackgroundColor: (c) => {
            const meta = data.pointsMeta[c.dataIndex];
            if (!meta?.isBooking) return "rgba(0,0,0,0)";
            return meta.isOwner ? "#ff8a2a" : "#ffffff";
          },
          pointBorderColor: "rgba(0,0,0,0)",
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { right: 20, top: 10 } },
      plugins: {
        legend: { display: false },
        tooltip: {
          enabled: true,

          // ✅ precieze hover: alleen bij punten
          mode: "nearest",
          intersect: true,

          // ✅ styling
          backgroundColor: "rgba(11,18,37,0.95)",
          borderColor: "rgba(255,255,255,0.10)",
          borderWidth: 1,
          cornerRadius: 10,
          padding: 12,

          titleColor: "#ffffff",
          bodyColor: "#d1d5db",
          titleFont: { size: 13, weight: "600" },
          bodyFont: { size: 12 },

          displayColors: false,

          callbacks: {
            title: (items) => {
              const meta = data.pointsMeta[items[0].dataIndex];
              return meta?.date ?? "";
            },
            label: (item) => {
              const meta = data.pointsMeta[item.dataIndex];
              if (!meta?.isBooking) return "";

              const lines = [
                `Omzet boeking: ${fmtEUR(meta.amount)}`,
                `Cumulatief: ${fmtEUR(item.raw)}`,
                `Nachten: ${meta.nights}`,
              ];

              if (meta.isOwner) lines.push("Type: Huiseigenaar");
              return lines;
            },
          },
        },

      },
      scales: {
        x: {
          type: "time",
          time: { unit: "month", displayFormats: { month: "MMM yyyy" } },
          grid: { color: "rgba(255,255,255,0.05)" },
          ticks: { color: "#8b949e", font: { size: 13 } },
        },
        y: {
          beginAtZero: true,
          grid: { color: "rgba(255,255,255,0.05)" },

          // ✅ we verbergen de y ticks in de chart zelf
          ticks: { display: false },
          border: { display: false },
        },
      },
    },
  });

  // ✅ NA layout: sticky y-as labels (DOM) bijwerken
  requestAnimationFrame(() => {
    renderStickyYAxisLabelsFromChart(state.charts.homeCumulativeRevenue);
  });
}


/* ============================================================
 * Helpers (Home)
 * ============================================================ */

function getUniqueYearsCount(rows) {
  const years = new Set(rows.map((r) => r.__aankomst?.getFullYear()).filter((y) => Number.isFinite(y)));
  return years.size || 1;
}

function setCountUp(id, targetNumber, {
  duration = 2000,
  formatter = (v) => String(Math.round(v)),
  fromOnFirst = 0,              // 👈 nieuw: startwaarde bij eerste keer
} = {}) {
  const el = document.getElementById(id);
  if (!el) return;

  const to = Number(targetNumber ?? 0);
  if (!Number.isFinite(to)) {
    el.textContent = formatter(0);
    el.dataset.prevValue = "0";
    return;
  }

  // 👇 als er nog geen prevValue is (bijv. na upload), start dan vanaf 0 en ANIMEER
  const hasPrev = el.dataset.prevValue != null && el.dataset.prevValue !== "";
  const from = hasPrev ? Number(el.dataset.prevValue) : Number(fromOnFirst);

  // fallback als from onbruikbaar is
  const safeFrom = Number.isFinite(from) ? from : 0;

  const start = performance.now();
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);

  const tick = (now) => {
    const t = Math.min(1, (now - start) / duration);
    const k = easeOutCubic(t);
    const val = safeFrom + (to - safeFrom) * k;

    el.textContent = formatter(val);

    if (t < 1) requestAnimationFrame(tick);
    else el.dataset.prevValue = String(to);
  };

  requestAnimationFrame(tick);
}



function fmtEUR(n) {
  const val = Number(n);
  if (!Number.isFinite(val)) return "€ 0,00";
  return val.toLocaleString("nl-NL", { style: "currency", currency: "EUR" });
}

function renderStickyYAxisLabelsFromChart(chart) {
  const wrap = document.getElementById("cumYAxis");
  if (!wrap || !chart?.scales?.y) return;

  const yScale = chart.scales.y;

  // ✅ omkeren: boven = max, onder = 0
  const ticks = [...(yScale.ticks || [])].reverse();

  wrap.innerHTML = "";
  ticks.forEach((t) => {
    const span = document.createElement("span");
    span.textContent = "€" + Number(t.value).toLocaleString("nl-NL");
    wrap.appendChild(span);
  });
}



function setScrollableChartWidth(pointsCount) {
  const inner = document.getElementById("cumScrollInner");
  if (!inner) return;
  inner.style.minWidth = Math.max(1000, pointsCount * 5) + "px";
}

function aggCumulativeDaily(rows) {
  if (!rows || rows.length === 0) return { labels: [], values: [], pointsMeta: [] };

  const sorted = [...rows].sort((a, b) => a.__aankomst - b.__aankomst);
  const start = new Date(sorted[0].__aankomst);
  const end = new Date(sorted[sorted.length - 1].__aankomst);

  const byDay = new Map();

  for (const r of sorted) {
    const d = r.__aankomst;
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

    const amount = state.currentMode === "gross" ? (r.__gross || 0) : (r.__net || 0);
    const nights = r.__nights || 0;

    const prev = byDay.get(key) || { amount: 0, nights: 0, hasBooking: false, isOwner: false };
    byDay.set(key, {
      amount: prev.amount + amount,
      nights: prev.nights + nights,
      hasBooking: true,
      isOwner: prev.isOwner || !!r.__owner,
    });
  }

  const labels = [];
  const values = [];
  const pointsMeta = [];

  let sum = 0;
  const iter = new Date(start);

  while (iter <= end) {
    const key = `${iter.getFullYear()}-${String(iter.getMonth() + 1).padStart(2, "0")}-${String(iter.getDate()).padStart(2, "0")}`;
    const info = byDay.get(key);

    if (info?.hasBooking) {
      sum += info.amount;
      pointsMeta.push({
        isBooking: true,
        amount: info.amount,
        nights: info.nights,
        date: iter.toLocaleDateString("nl-NL", { day: "numeric", month: "short", year: "numeric" }),
        isOwner: !!info.isOwner,
      });
    } else {
      pointsMeta.push(null);
    }

    labels.push(new Date(iter));
    values.push(sum);
    iter.setDate(iter.getDate() + 1);
  }

  return { labels, values, pointsMeta };
}
